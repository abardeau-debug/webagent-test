# Atelier Lune — Prototype (environnement de test isole)

Prototype Astro de demonstration, 4 pages (Accueil, L'atelier, Creations, Contact).
Contenus et visuels fictifs, clairement signales dans l'interface. Formulaire de
contact en demonstration : aucune donnee n'est envoyee ni conservee (JavaScript
cote client uniquement, pas de backend).

## Statut de preuve
- Code des pages/composants : redige, non execute (aucune installation ni build
  n'a ete lancee sans autorisation explicite).
- Palette de couleurs : verifiee par un script de contraste WCAG execute en
  sandbox (voir scripts/contrast-check.mjs et le resultat communique dans la
  reponse de l'agent).
- Aucune operation GitHub, Cloudflare ou deploiement n'a ete effectuee.

## Pour verifier reellement le prototype (necessite une autorisation prealable)
```
npm install
npm run dev      # previsualisation locale
npm run build    # build de production (verifie la compilation reelle)
```
La version d'Astro n'a pas ete figee precisement ("latest") : verifier la
version resolue par npm et la compatibilite avec l'hebergeur cible avant toute
mise en production, et envisager de la figer dans package.json.

## Limites connues de ce prototype
- Pas de sitemap.xml ni d'integration @astrojs/sitemap (prevu dans le plan
  d'architecture, non implemente ici pour rester dans le perimetre demande).
- Pas de lightbox sur la galerie (grille statique uniquement), pour limiter le
  JavaScript non teste.
- Visuels en SVG place-holder generes localement, a remplacer par de vraies
  photographies optimisees (AVIF/WebP) avant production.
- API des collections de contenu Astro (`src/content/config.ts`) ecrite selon
  le schema classique `defineCollection` ; a verifier selon la version d'Astro
  reellement installee (API susceptible d'evoluer).
