import { defineConfig } from 'astro/config';

// site : domaine placeholder, a remplacer par le domaine reel avant mise en ligne
export default defineConfig({
  output: 'static',
  site: 'https://exemple-atelier-lune.fr',
});
