function hexToRgb(hex) {
  const n = hex.replace('#', '');
  const bigint = parseInt(n, 16);
  return [(bigint >> 16) & 255, (bigint >> 8) & 255, bigint & 255];
}
function channelLin(c) {
  const cs = c / 255;
  return cs <= 0.03928 ? cs / 12.92 : Math.pow((cs + 0.055) / 1.055, 2.4);
}
function luminance([r, g, b]) {
  const [rl, gl, bl] = [channelLin(r), channelLin(g), channelLin(b)];
  return 0.2126 * rl + 0.7152 * gl + 0.0722 * bl;
}
function contrast(hex1, hex2) {
  const l1 = luminance(hexToRgb(hex1));
  const l2 = luminance(hexToRgb(hex2));
  const [lighter, darker] = l1 > l2 ? [l1, l2] : [l2, l1];
  return (lighter + 0.05) / (darker + 0.05);
}

const pairs = [
  ['Texte principal / fond crème', '#2E2A26', '#FAF6F0', 4.5],
  ['Texte atténué / fond carte (bg-alt)', '#5C5048', '#F1E6DA', 4.5],
  ['Accent (liens) / fond crème', '#9A4E30', '#FAF6F0', 4.5],
  ['Texte bouton blanc / fond accent', '#FFFFFF', '#9A4E30', 4.5],
  ['Texte crème / fond brun foncé (header/footer)', '#FAF6F0', '#3A2E27', 4.5],
  ['Texte principal / fond carte (bg-alt)', '#2E2A26', '#F1E6DA', 4.5],
  ['Bordure input (texte atténué) / blanc', '#5C5048', '#FFFFFF', 3],
];

console.log('Vérification des contrastes WCAG 2.2 (seuil AA)');
let allPass = true;
for (const [label, fg, bg, min] of pairs) {
  const ratio = contrast(fg, bg);
  const pass = ratio >= min;
  if (!pass) allPass = false;
  console.log(`${pass ? 'OK  ' : 'FAIL'} ${label}: ${ratio.toFixed(2)}:1 (seuil ${min}:1)`);
}
console.log(allPass ? '\nRésultat global : toutes les paires testées passent le seuil AA.' : '\nRésultat global : au moins une paire échoue, palette à ajuster.');
