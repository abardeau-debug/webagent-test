import { defineCollection, z } from 'astro:content';
import { glob } from 'astro/loaders';

// Astro 7 : l'ancienne API "type: 'content'" dans src/content/config.ts est
// supprimée (legacy content collections). Nouvelle API : loader + fichier
// src/content.config.ts à la racine de src/.
const creations = defineCollection({
  loader: glob({ pattern: '**/*.md', base: './src/content/creations' }),
  schema: z.object({
    title: z.string(),
    material: z.string(),
    dimensions: z.string(),
    image: z.string(),
    alt: z.string(),
  }),
});

export const collections = { creations };
