---
title: "Assiette Argile"
material: "Grès rouge, émail transparent"
dimensions: "Ø 22 cm"
image: "/images/placeholders/piece-assiette.svg"
alt: "Visuel fictif : assiette en grès rouge naturel"
---

[Texte fictif à des fins de démonstration] Une assiette plate en grès rouge brut, laissant apparaître la teinte naturelle de la terre sous un émail transparent.
