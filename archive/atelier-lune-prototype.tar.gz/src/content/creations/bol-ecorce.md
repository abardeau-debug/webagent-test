---
title: "Bol Écorce"
material: "Grès chamotté, émail mat brun"
dimensions: "Ø 16 cm, h. 7 cm"
image: "/images/placeholders/piece-bol.svg"
alt: "Visuel fictif : bol en grès à la surface texturée imitant l'écorce"
---

[Texte fictif à des fins de démonstration] Un bol façonné dans une terre chamottée, à la surface irrégulière évoquant l'écorce d'un arbre.
