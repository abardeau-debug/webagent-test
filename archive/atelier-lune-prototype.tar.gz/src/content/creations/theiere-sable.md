---
title: "Théière Sable"
material: "Grès, émail sablé beige"
dimensions: "H. 14 cm, 0,8 L"
image: "/images/placeholders/piece-theiere.svg"
alt: "Visuel fictif : théière en grès de teinte sable"
---

[Texte fictif à des fins de démonstration] Une théière compacte, pensée pour un usage quotidien, à l'émail sablé mat.
