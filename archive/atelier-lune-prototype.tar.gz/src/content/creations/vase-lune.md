---
title: "Vase Lune"
material: "Porcelaine, émail blanc craquelé"
dimensions: "H. 24 cm, Ø 12 cm"
image: "/images/placeholders/piece-vase.svg"
alt: "Visuel fictif : vase en porcelaine blanche de forme arrondie"
---

[Texte fictif à des fins de démonstration] Un vase en porcelaine, à la silhouette ronde et lunaire, recouvert d'un émail craquelé.
