const albums=[
{title:'BLACKCLOUD',kind:'album',image:'a4017190102_2.jpg',path:'album/blackcloud'},
{title:'MOVING LIKE ZOMBIES',artist:'B.ROCK & NOKTURN',kind:'single',image:'a3689091069_2.jpg',path:'track/b-rock-nokturn-moving-like-zombies'},
{title:'THE HORROR STORY',kind:'album',image:'a1886099549_2.jpg',path:'album/the-horror-story'},
{title:'PINK CITY',kind:'album',image:'a1539445621_2.jpg',path:'album/pink-city'},
{title:'LOS ZONARDOS',kind:'album',image:'a4158145155_2.jpg',path:'album/los-zonardos-2'},
{title:'BLOOD & HOOD',kind:'album',image:'a3228897534_2.jpg',path:'album/blood-hood'},
{title:'BLACK MOON',kind:'album',image:'a1356393753_2.jpg',path:'album/black-moon'},
{title:'THA FONK RYDERZ',kind:'album',image:'a0071784756_2.jpg',path:'album/tha-fonk-ryderz'}];
let filter='all';const grid=document.querySelector('#albums'),search=document.querySelector('input[type=search]');
function render(){const shown=albums.filter(a=>(filter==='all'||a.kind===filter)&&(a.title+' '+(a.artist||'B.ROCK')).toLowerCase().includes(search.value.toLowerCase().trim()));grid.innerHTML=shown.map(a=>`<a class="album" href="https://brock31.bandcamp.com/${a.path}" target="_blank" rel="noopener" aria-label="Découvrir ${a.title} sur Bandcamp"><div class="artwork"><img src="https://f4.bcbits.com/img/${a.image}" alt="Pochette ${a.title}" loading="lazy"><span class="album-arrow" aria-hidden="true">↗</span></div><h3>${a.title}</h3><p>${a.artist||'B.ROCK'} · ${a.kind==='single'?'Single':'Projet'}</p></a>`).join('');document.querySelector('.empty').hidden=shown.length>0;}
document.querySelectorAll('[data-filter]').forEach(b=>b.addEventListener('click',()=>{filter=b.dataset.filter;document.querySelectorAll('[data-filter]').forEach(x=>{x.classList.toggle('selected',x===b);x.setAttribute('aria-pressed',String(x===b))});render()}));search.addEventListener('input',render);render();
